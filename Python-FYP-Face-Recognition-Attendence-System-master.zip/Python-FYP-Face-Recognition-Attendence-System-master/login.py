from tkinter import* 
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
from register import Register
import mysql.connector
import pymysql
import re  # Import regex module for email validation
pymysql.install_as_MySQLdb()
# --------------------------
from train import Train
from student import Student
from train import Train
from face_recognition import Face_Recognition
from attendance import Attendance
from developer import Developer
from helpsupport import Helpsupport
import os


class Login:
    def __init__(self,root):
        self.root=root
        self.root.title("Login")
        self.root.geometry("1366x768+0+0")

        # variables 
        self.var_ssq=StringVar()
        self.var_sa=StringVar()
        self.var_pwd=StringVar()

        self.bg=ImageTk.PhotoImage(file=r"C:\Users\USER\Downloads\bluee.webp")
        
        lb1_bg=Label(self.root,image=self.bg)
        lb1_bg.place(x=0,y=0, relwidth=1,relheight=1)

        frame1= Frame(self.root,bg="#002B53")
        frame1.place(x=500,y=170,width=340,height=450)

        img1=Image.open(r"C:\Users\USER\Documents\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\log1.png")
        img1=img1.resize((100,100), Image.LANCZOS)
        self.photoimage1=ImageTk.PhotoImage(img1)
        lb1img1 = Label(image=self.photoimage1,bg="#002B53")
        lb1img1.place(x=630,y=175, width=100,height=100)

        get_str = Label(frame1,text="Login",font=("times new roman",20,"bold"),fg="white",bg="#002B53")
        get_str.place(x=140,y=100)

        #label1 
        username =lb1= Label(frame1,text="Email:",font=("times new roman",15,"bold"),fg="white",bg="#002B53")
        username.place(x=30,y=160)

        #entry1 
        self.txtuser=ttk.Entry(frame1,font=("times new roman",15,"bold"))
        self.txtuser.place(x=33,y=190,width=270)


        #label2 
        pwd =lb1= Label(frame1,text="Password:",font=("times new roman",15,"bold"),fg="white",bg="#002B53")
        pwd.place(x=30,y=230)

        #entry2 
        self.txtpwd=ttk.Entry(frame1,font=("times new roman",15,"bold"), show="*")  # Added show="*" to hide password
        self.txtpwd.place(x=33,y=260,width=270)

        # Email validation status
        self.email_status = Label(frame1, text="", font=("times new roman", 10), fg="white", bg="#002B53")
        self.email_status.place(x=33, y=215, width=270)

        # Password validation status
        self.pwd_status = Label(frame1, text="", font=("times new roman", 10), fg="white", bg="#002B53")
        self.pwd_status.place(x=33, y=285, width=270)

        # Bind validation functions to entry field events
        self.txtuser.bind("<FocusOut>", self.validate_email)
        self.txtpwd.bind("<FocusOut>", self.validate_password)


        # Creating Button Login
        loginbtn=Button(frame1,command=self.login,text="Login",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="#002B53",bg="white",activeforeground="white",activebackground="#007ACC")
        loginbtn.place(x=33,y=320,width=270,height=35)


        # Creating Button Registration
        loginbtn=Button(frame1,command=self.reg,text="Register",font=("times new roman",10,"bold"),bd=0,relief=RIDGE,fg="white",bg="#002B53",activeforeground="orange",activebackground="#002B53")
        loginbtn.place(x=33,y=370,width=50,height=20)


        # Creating Button Forget
        loginbtn=Button(frame1,command=self.forget_pwd,text="Forget",font=("times new roman",10,"bold"),bd=0,relief=RIDGE,fg="white",bg="#002B53",activeforeground="orange",activebackground="#002B53")
        loginbtn.place(x=90,y=370,width=50,height=20)

    # Validate email format
    def validate_email(self, event=None):
        email = self.txtuser.get()
        # Regular expression pattern for email validation
        pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
        
        if email == "":
            self.email_status.config(text="")
            return False
        
        if re.match(pattern, email):
            self.email_status.config(text="Valid email format", fg="green")
            return True
        else:
            self.email_status.config(text="Invalid email format", fg="red")
            return False
            
    # Validate password strength
    def validate_password(self, event=None):
        password = self.txtpwd.get()
        
        if password == "":
            self.pwd_status.config(text="")
            return False
        
        # Check password length
        if len(password) < 8:
            self.pwd_status.config(text="Password too short (min 8 chars)", fg="red")
            return False
        
        # Check for password strength (optional - can be modified)
        has_digit = any(char.isdigit() for char in password)
        has_upper = any(char.isupper() for char in password)
        has_lower = any(char.islower() for char in password)
        has_special = any(not char.isalnum() for char in password)
        
        if has_digit and has_upper and has_lower and has_special:
            self.pwd_status.config(text="Strong password", fg="green")
            return True
        elif (has_digit and has_upper) or (has_lower and has_special) or (has_upper and has_special):
            self.pwd_status.config(text="Moderate password", fg="yellow")
            return True
        else:
            self.pwd_status.config(text="Weak password", fg="orange")
            return True  # Still allow login with weak password
    
    #  THis function is for open register window
    def reg(self):
        self.new_window=Toplevel(self.root)
        self.app=Register(self.new_window)


    def login(self):
        # First validate input fields
        is_valid_email = self.validate_email()
        is_valid_pwd = self.validate_password()
        
        if not is_valid_email:
            messagebox.showerror("Error", "Please enter a valid email address!")
            return
            
        if not is_valid_pwd:
            messagebox.showerror("Error", "Please enter a valid password!")
            return
            
        if (self.txtuser.get()=="" or self.txtpwd.get()==""):
            messagebox.showerror("Error","All Fields Required!")
        elif(self.txtuser.get()=="admin" and self.txtpwd.get()=="admin"):
            messagebox.showinfo("Successfully","Welcome to Attendance Management System Using Facial Recognition")
        else:
            # messagebox.showerror("Error","Please Check Username or Password !")
            conn = mysql.connector.connect(user='root', password='Isha@1234',host='localhost',database='face_recognition',port=3306)
            mycursor = conn.cursor()
            mycursor.execute("select * from regteach where email=%s and pwd=%s",(
                self.txtuser.get(),
                self.txtpwd.get()
            ))
            row=mycursor.fetchone()
            if row==None:
                messagebox.showerror("Error","Invalid Username and Password!")
            else:
                open_min=messagebox.askyesno("YesNo","Access only Admin")
                if open_min>0:
                    self.new_window=Toplevel(self.root)
                    self.app=Face_Recognition_System(self.new_window)
                else:
                    if not open_min:
                        return
                conn.commit()
                conn.close()
#=======================Reset Password Function=============================
    def reset_pass(self):
        # Validate new password
        password = self.var_pwd.get()
        if len(password) < 8:
            messagebox.showerror("Error","Password must be at least 8 characters long!",parent=self.root2)
            return
            
        # Check for password strength (can be modified based on requirements)
        has_digit = any(char.isdigit() for char in password)
        has_upper = any(char.isupper() for char in password)
        has_lower = any(char.islower() for char in password)
        has_special = any(not char.isalnum() for char in password)
        
        if not (has_digit and has_upper and has_lower and has_special):
            messagebox.showwarning("Warning","Password should include uppercase, lowercase, digits and special characters!",parent=self.root2)
            # Continue anyway - just a warning
        
        if self.var_ssq.get()=="Select":
            messagebox.showerror("Error","Select the Security Question!",parent=self.root2)
        elif(self.var_sa.get()==""):
            messagebox.showerror("Error","Please Enter the Answer!",parent=self.root2)
        elif(self.var_pwd.get()==""):
            messagebox.showerror("Error","Please Enter the New Password!",parent=self.root2)
        else:
            conn = mysql.connector.connect(user='root', password='Isha@1234',host='localhost',database='face_recognition',port=3306)
            mycursor = conn.cursor()
            query=("select * from regteach where email=%s and ss_que=%s and s_ans=%s")
            value=(self.txtuser.get(),self.var_ssq.get(),self.var_sa.get())
            mycursor.execute(query,value)
            row=mycursor.fetchone()
            if row==None:
                messagebox.showerror("Error","Please Enter the Correct Answer!",parent=self.root2)
            else:
                query=("update regteach set pwd=%s where email=%s")
                value=(self.var_pwd.get(),self.txtuser.get())
                mycursor.execute(query,value)

                conn.commit()
                conn.close()
                messagebox.showinfo("Info","Successfully Your password has been reset, Please login with new Password!",parent=self.root2)
                



# =====================Forget window=========================================
    def forget_pwd(self):
        if self.txtuser.get()=="":
            messagebox.showerror("Error","Please Enter the Email ID to reset Password!")
        elif not self.validate_email():
            messagebox.showerror("Error","Please Enter a Valid Email Address!")
        else:
            conn = mysql.connector.connect(user='root', password='Isha@1234',host='localhost',database='face_recognition',port=3306)
            mycursor = conn.cursor()
            query=("select * from regteach where email=%s")
            value=(self.txtuser.get(),)
            mycursor.execute(query,value)
            row=mycursor.fetchone()
# print(row)

        if row==None:
            messagebox.showerror("Error","Please Enter the Valid Email ID!")
        else:
            conn.close()
            self.root2=Toplevel()
            self.root2.title("Forget Password")
            self.root2.geometry("400x400+610+170")
            l=Label(self.root2,text="Forget Password",font=("times new roman",30,"bold"),fg="#002B53",bg="#fff")
            l.place(x=0,y=10,relwidth=1)
            # -------------------fields-------------------
            #label1 
            ssq =lb1= Label(self.root2,text="Select Security Question:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
            ssq.place(x=70,y=80)

            #Combo Box1
            self.combo_security = ttk.Combobox(self.root2,textvariable=self.var_ssq,font=("times new roman",15,"bold"),state="readonly")
            self.combo_security["values"]=("Select","Your Date of Birth","Your Nick Name","Your Favorite Book")
            self.combo_security.current(0)
            self.combo_security.place(x=70,y=110,width=270)


            #label2 
            sa =lb1= Label(self.root2,text="Security Answer:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
            sa.place(x=70,y=150)

            #entry2 
            self.txtpwd=ttk.Entry(self.root2,textvariable=self.var_sa,font=("times new roman",15,"bold"))
            self.txtpwd.place(x=70,y=180,width=270)

            #label2 
            new_pwd =lb1= Label(self.root2,text="New Password:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
            new_pwd.place(x=70,y=220)

            #entry2 
            self.new_pwd=ttk.Entry(self.root2,textvariable=self.var_pwd,font=("times new roman",15,"bold"), show="*")
            self.new_pwd.place(x=70,y=250,width=270)

            # Password strength indicator
            self.pwd_indicator = Label(self.root2, text="", font=("times new roman",10), fg="#002B53", bg="#F2F2F2")
            self.pwd_indicator.place(x=70, y=280, width=270)
            
            # Bind password validation to the new password field
            self.new_pwd.bind("<KeyRelease>", self.check_password_strength)

            # Creating Button New Password
            loginbtn=Button(self.root2,command=self.reset_pass,text="Reset Password",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="#fff",bg="#002B53",activeforeground="white",activebackground="#007ACC")
            loginbtn.place(x=70,y=320,width=270,height=35)

    # Check password strength for the reset password window
    def check_password_strength(self, event=None):
        password = self.var_pwd.get()
        
        if password == "":
            self.pwd_indicator.config(text="")
            return
            
        # Check password length
        if len(password) < 8:
            self.pwd_indicator.config(text="Password too short (min 8 chars)", fg="red")
            return
            
        # Check for password strength
        has_digit = any(char.isdigit() for char in password)
        has_upper = any(char.isupper() for char in password)
        has_lower = any(char.islower() for char in password)
        has_special = any(not char.isalnum() for char in password)
        
        strength = 0
        criteria = [has_digit, has_upper, has_lower, has_special]
        for criteria_met in criteria:
            if criteria_met:
                strength += 1
                
        if strength == 4:
            self.pwd_indicator.config(text="Strong password", fg="green")
        elif strength == 3:
            self.pwd_indicator.config(text="Moderate password", fg="blue")
        elif strength == 2:
            self.pwd_indicator.config(text="Fair password", fg="orange")
        else:
            self.pwd_indicator.config(text="Weak password", fg="red")
            

# =====================main program Face deteion system====================

class Face_Recognition_System:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1366x768+0+0")
        self.root.title("Face_Recogonition_System")

# This part is image labels setting start 
        # first header image  
        img=Image.open(r"C:\Users\USER\Documents\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\banner.jpg")
        img=img.resize((1366,130),Image.LANCZOS)
        self.photoimg=ImageTk.PhotoImage(img)

        # set image as lable
        f_lb1 = Label(self.root,image=self.photoimg)
        f_lb1.place(x=0,y=0,width=1366,height=130)

        # backgorund image 
        bg1=Image.open(r"C:\Users\USER\Documents\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\bg3.jpg")
        bg1=bg1.resize((1366,768),Image.LANCZOS)
        self.photobg1=ImageTk.PhotoImage(bg1)

        # set image as lable
        bg_img = Label(self.root,image=self.photobg1)
        bg_img.place(x=0,y=130,width=1366,height=768)


        #title section
        title_lb1 = Label(bg_img,text="Attendance Managment System Using Facial Recognition",font=("verdana",30,"bold"),bg="white",fg="navyblue")
        title_lb1.place(x=0,y=0,width=1366,height=45)

        # Create buttons below the section 
        # ------------------------------------------------------------------------------------------------------------------- 
        # student button 1
        std_img_btn=Image.open(r"C:\Users\USER\Documents\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\std1.jpg")
        std_img_btn=std_img_btn.resize((180,180),Image.LANCZOS)
        self.std_img1=ImageTk.PhotoImage(std_img_btn)

        std_b1 = Button(bg_img,command=self.student_pannels,image=self.std_img1,cursor="hand2")
        std_b1.place(x=250,y=100,width=180,height=180)

        std_b1_1 = Button(bg_img,command=self.student_pannels,text="Student Pannel",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        std_b1_1.place(x=250,y=280,width=180,height=45)

        # Detect Face  button 2
        det_img_btn=Image.open(r"C:\Users\USER\Documents\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\det1.jpg")
        det_img_btn=det_img_btn.resize((180,180),Image.LANCZOS)
        self.det_img1=ImageTk.PhotoImage(det_img_btn)

        det_b1 = Button(bg_img,command=self.face_rec,image=self.det_img1,cursor="hand2",)
        det_b1.place(x=480,y=100,width=180,height=180)

        det_b1_1 = Button(bg_img,command=self.face_rec,text="Face Detector",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        det_b1_1.place(x=480,y=280,width=180,height=45)

         # Attendance System  button 3
        att_img_btn=Image.open(r"C:\Users\USER\Documents\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\att.jpg")
        att_img_btn=att_img_btn.resize((180,180),Image.LANCZOS)
        self.att_img1=ImageTk.PhotoImage(att_img_btn)

        att_b1 = Button(bg_img,command=self.attendance_pannel,image=self.att_img1,cursor="hand2",)
        att_b1.place(x=710,y=100,width=180,height=180)

        att_b1_1 = Button(bg_img,command=self.attendance_pannel,text="Attendance",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        att_b1_1.place(x=710,y=280,width=180,height=45)

         # Help  Support  button 4
        hlp_img_btn=Image.open(r"C:\Users\USER\Documents\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\hlp.jpg")
        hlp_img_btn=hlp_img_btn.resize((180,180),Image.LANCZOS)
        self.hlp_img1=ImageTk.PhotoImage(hlp_img_btn)

        hlp_b1 = Button(bg_img,image=self.hlp_img1,cursor="hand2",)
        hlp_b1.place(x=940,y=100,width=180,height=180)

        hlp_b1_1 = Button(bg_img,text="Help Support",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        hlp_b1_1.place(x=940,y=280,width=180,height=45)

        # Top 4 buttons end.......
        # ---------------------------------------------------------------------------------------------------------------------------
        # Start below buttons.........
         # Train   button 5
        tra_img_btn=Image.open(r"C:\Users\USER\Documents\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\tra1.jpg")
        tra_img_btn=tra_img_btn.resize((180,180),Image.LANCZOS)
        self.tra_img1=ImageTk.PhotoImage(tra_img_btn)

        tra_b1 = Button(bg_img,command=self.train_pannels,image=self.tra_img1,cursor="hand2",)
        tra_b1.place(x=250,y=330,width=180,height=180)

        tra_b1_1 = Button(bg_img,command=self.train_pannels,text="Data Train",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        tra_b1_1.place(x=250,y=510,width=180,height=45)

        # Photo   button 6
        pho_img_btn=Image.open(r"C:\Users\USER\Documents\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\qr1.png")
        pho_img_btn=pho_img_btn.resize((180,180),Image.LANCZOS)
        self.pho_img1=ImageTk.PhotoImage(pho_img_btn)

        pho_b1 = Button(bg_img,command=self.open_img,image=self.pho_img1,cursor="hand2",)
        pho_b1.place(x=480,y=330,width=180,height=180)

        pho_b1_1 = Button(bg_img,command=self.open_img,text="QR-Codes",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        pho_b1_1.place(x=480,y=510,width=180,height=45)

        # Developers   button 7
        dev_img_btn=Image.open(r"C:\Users\USER\Documents\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\dev.jpg")
        dev_img_btn=dev_img_btn.resize((180,180),Image.LANCZOS)
        self.dev_img1=ImageTk.PhotoImage(dev_img_btn)

        dev_b1 = Button(bg_img,command=self.developr,image=self.dev_img1,cursor="hand2",)
        dev_b1.place(x=710,y=330,width=180,height=180)

        dev_b1_1 = Button(bg_img,command=self.developr,text="Developers",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        dev_b1_1.place(x=710,y=510,width=180,height=45)

        # exit   button 8
        exi_img_btn=Image.open(r"C:\Users\USER\Documents\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\exi.jpg")
        exi_img_btn=exi_img_btn.resize((180,180),Image.LANCZOS)
        self.exi_img1=ImageTk.PhotoImage(exi_img_btn)

        exi_b1 = Button(bg_img,image=self.exi_img1,cursor="hand2",)
        exi_b1.place(x=940,y=330,width=180,height=180)

        exi_b1_1 = Button(bg_img,text="Exit",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        exi_b1_1.place(x=940,y=510,width=180,height=45)

# ==================Funtion for Open Images Folder==================
    def open_img(self):
        os.startfile("data_img")
# ==================Functions Buttons=====================
    def student_pannels(self):
        self.new_window=Toplevel(self.root)
        self.app=Student(self.new_window)

    def train_pannels(self):
        self.new_window=Toplevel(self.root)
        self.app=Train(self.new_window)
    
    def face_rec(self):
        self.new_window=Toplevel(self.root)
        self.app=Face_Recognition(self.new_window)
    
    def attendance_pannel(self):
        self.new_window=Toplevel(self.root)
        self.app=Attendance(self.new_window)
    
    def developr(self):
        self.new_window=Toplevel(self.root)
        self.app=Developer(self.new_window)
    
    def open_img(self):
        os.startfile("dataset")
    
  




if __name__ == "__main__":
    root=Tk()
    app=Login(root)
    root.mainloop()