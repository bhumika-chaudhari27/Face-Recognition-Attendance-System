ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Isha@1234';
FLUSH PRIVILEGES;